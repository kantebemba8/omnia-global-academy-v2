import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": Deno.env.get("ALLOWED_ORIGIN") || "https://omniaglobalacademy.com",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

function json(d: unknown, s = 200) {
  return new Response(JSON.stringify(d), {
    status: s,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS")
    return new Response(null, { status: 200, headers: corsHeaders });

  const token = (req.headers.get("Authorization") ?? "").replace(/^Bearer\s+/i, "").trim();
  if (!token) return json({ error: "AUTH_REQUIRED" }, 401);

  let body: { lesson_id?: string; text?: string };
  try { body = await req.json(); } catch { return json({ error: "Invalid body" }, 400); }

  const { lesson_id, text } = body;
  if (!text || !lesson_id) return json({ error: "text + lesson_id requis" }, 400);

  const sb = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
  );

  const { data: sess } = await sb.from("user_sessions")
    .select("user_id")
    .eq("session_token", token)
    .gt("expires_at", new Date().toISOString())
    .maybeSingle();
  if (!sess) return json({ error: "SESSION_INVALID" }, 401);

  try {
    const ttsResp = await fetch("https://api.openai.com/v1/audio/speech", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${Deno.env.get("OPENAI_API_KEY")}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "tts-1",
        input: (text as string).substring(0, 4096),
        voice: "nova",
        response_format: "mp3",
        speed: 0.9,
      }),
    });

    if (!ttsResp.ok) return json({ error: "TTS_FAILED" }, 500);

    const audioBuffer = await ttsResp.arrayBuffer();
    const r2Key = `audio/lessons/${lesson_id}/tts_${Date.now()}.mp3`;
    const r2AccountId = Deno.env.get("CF_ACCOUNT_ID") ?? "";
    const r2Bucket = Deno.env.get("CF_R2_BUCKET") ?? "";
    const r2Url = `https://${r2AccountId}.r2.cloudflarestorage.com/${r2Bucket}/${r2Key}`;

    await fetch(r2Url, {
      method: "PUT",
      headers: { "Content-Type": "audio/mpeg" },
      body: audioBuffer,
    });

    const audioUrl = `https://pub-${r2AccountId}.r2.dev/${r2Key}`;
    await sb.from("course_lessons").update({ audio_url: audioUrl }).eq("id", lesson_id);

    return json({
      success: true,
      audio_url: audioUrl,
      duration_estimate: Math.round((text as string).split(/\s+/).length / 150 * 60),
    });
  } catch (err) {
    console.error(err);
    return json({ error: "SERVER_ERROR" }, 500);
  }
});
