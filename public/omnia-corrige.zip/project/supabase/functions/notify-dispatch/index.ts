import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";
import { sendBrevoEmail, sendAfricasTalkingSMS, notifyUser } from "../_shared/notifications.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

function json(d: unknown, s = 200) {
  return new Response(JSON.stringify(d), { status: s, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 200, headers: corsHeaders });

  try {
    const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const appUrl = Deno.env.get("APP_URL") || "https://omniaglobalacademy.com";

    const body = await req.json();
    const { type, payload } = body as { type: string; payload: Record<string, unknown> };
    if (!type || !payload) return json({ error: "MISSING_FIELDS" }, 400);

    switch (type) {

      case "inscription_apprenant": {
        await notifyUser({
          userId: payload.userId as string,
          emailConfig: {
            templateId: 4,
            from: "admission@omniaglobalacademy.com",
            params: {
              ROLE_NAME: "Apprenant",
              MESSAGE_SPECIFIQUE: "Votre compte est actif. Explorez des centaines de formations !",
              DASHBOARD_URL: `${appUrl}/dashboard`,
            },
          },
          smsMessage: `Bienvenue sur Omnia Academy ! Votre compte est actif. Commencez dès maintenant : ${appUrl}`,
          sb,
        });
        break;
      }

      case "inscription_professeur": {
        await notifyUser({
          userId: payload.userId as string,
          emailConfig: {
            templateId: 4,
            from: "admission@omniaglobalacademy.com",
            params: {
              ROLE_NAME: "Formateur",
              MESSAGE_SPECIFIQUE: "Votre dossier est en cours de vérification (24-48h ouvrées). Vous serez notifié dès validation.",
              DASHBOARD_URL: `${appUrl}/professeur/dashboard`,
            },
          },
          sb,
        });
        break;
      }

      case "inscription_etablissement": {
        await notifyUser({
          userId: payload.userId as string,
          emailConfig: {
            templateId: 4,
            from: "admission@omniaglobalacademy.com",
            params: {
              ROLE_NAME: "Établissement",
              MESSAGE_SPECIFIQUE: "Votre dossier est en cours de vérification (24-48h ouvrées). Vous serez notifié dès validation.",
              DASHBOARD_URL: `${appUrl}/school/dashboard`,
            },
          },
          sb,
        });
        break;
      }

      case "kyc_professeur_valide": {
        const { data: user } = await sb.from("users").select("full_name, email").eq("id", payload.userId as string).maybeSingle();
        const nameParts = (user?.full_name || "").split(" ");
        await notifyUser({
          userId: payload.userId as string,
          emailConfig: {
            templateId: 6,
            from: "admission@omniaglobalacademy.com",
            params: {
              NOM: nameParts.slice(1).join(" ") || nameParts[0],
              DOMAINE: payload.domaine as string || "",
              DASHBOARD_URL: `${appUrl}/professeur/dashboard`,
            },
          },
          smsMessage: `Omnia Academy : Votre compte Formateur est validé ! Créez votre première formation : ${appUrl}/professeur/dashboard`,
          sb,
        });
        break;
      }

      case "kyc_etablissement_valide": {
        await notifyUser({
          userId: payload.userId as string,
          emailConfig: {
            templateId: 7,
            from: "admission@omniaglobalacademy.com",
            params: {
              SCHOOL_NAME: payload.school_name as string,
              DIRECTOR_NAME: payload.director_name as string,
              DASHBOARD_URL: `${appUrl}/school/dashboard`,
            },
          },
          smsMessage: `Omnia Academy : Votre établissement ${payload.school_name} est validé. Accédez à votre espace : ${appUrl}/school/dashboard`,
          sb,
        });
        break;
      }

      case "kyc_rejete": {
        await notifyUser({
          userId: payload.userId as string,
          emailConfig: {
            templateId: 3,
            from: "admission@omniaglobalacademy.com",
            params: {
              FORMATION_TITRE: "Votre dossier",
              STATUT: "Rejeté",
              COMMENTAIRE: payload.raison as string || "Dossier incomplet.",
              MESSAGE_SPECIFIQUE: "Votre dossier n'a pas été validé. Veuillez corriger les éléments indiqués et resoumettre.",
              ACTION_URL: `${appUrl}/dashboard`,
            },
          },
          smsMessage: `Omnia Academy : Votre dossier n'a pas été validé. Consultez votre email pour les détails et corrections nécessaires.`,
          sb,
        });
        break;
      }

      case "formation_soumise_confirmation": {
        await notifyUser({
          userId: payload.userId as string,
          emailConfig: {
            templateId: 3,
            from: "admission@omniaglobalacademy.com",
            params: {
              FORMATION_TITRE: payload.formation_titre as string,
              STATUT: "En attente de validation",
              MESSAGE_SPECIFIQUE: "Votre formation a été soumise et sera examinée sous 24-48h ouvrées.",
              ACTION_URL: `${appUrl}/professeur/courses`,
            },
          },
          sb,
        });
        break;
      }

      case "formation_validee": {
        await notifyUser({
          userId: payload.userId as string,
          emailConfig: {
            templateId: 3,
            from: "admission@omniaglobalacademy.com",
            params: {
              FORMATION_TITRE: payload.formation_titre as string,
              STATUT: "Validée",
              PRIX_DEFINITIF: payload.prix_xof as string,
              MESSAGE_SPECIFIQUE: `Votre formation a été validée au prix de ${payload.prix_xof} XOF.`,
              ACTION_URL: `${appUrl}/professeur/courses`,
            },
          },
          sb,
        });
        break;
      }

      case "formation_publiee": {
        await notifyUser({
          userId: payload.userId as string,
          emailConfig: {
            templateId: 3,
            from: "admission@omniaglobalacademy.com",
            params: {
              FORMATION_TITRE: payload.formation_titre as string,
              STATUT: "Publiée",
              ACTION_URL: `${appUrl}/cours/${payload.course_id}`,
              MESSAGE_SPECIFIQUE: "Votre formation est maintenant visible dans le catalogue. Partagez le lien pour attirer vos premiers élèves !",
            },
          },
          smsMessage: `Omnia Academy : Votre formation "${payload.formation_titre}" est maintenant en ligne !`,
          sb,
        });
        break;
      }

      case "formation_rejetee": {
        await notifyUser({
          userId: payload.userId as string,
          emailConfig: {
            templateId: 3,
            from: "admission@omniaglobalacademy.com",
            params: {
              FORMATION_TITRE: payload.formation_titre as string,
              STATUT: "Rejetée",
              COMMENTAIRE: payload.commentaire as string,
              ACTION_URL: `${appUrl}/professeur/courses/${payload.course_id}/edit`,
              MESSAGE_SPECIFIQUE: "Votre formation n'a pas été acceptée. Consultez les corrections demandées.",
            },
          },
          smsMessage: `Omnia Academy : Votre formation "${payload.formation_titre}" nécessite des corrections. Consultez votre email.`,
          sb,
        });
        break;
      }

      case "modification_demandee": {
        await notifyUser({
          userId: payload.userId as string,
          emailConfig: {
            templateId: 3,
            from: "admission@omniaglobalacademy.com",
            params: {
              FORMATION_TITRE: payload.formation_titre as string,
              STATUT: "Modifications requises",
              COMMENTAIRE: payload.commentaire as string,
              ACTION_URL: `${appUrl}/professeur/courses/${payload.course_id}/edit`,
              MESSAGE_SPECIFIQUE: "Des modifications sont demandées pour votre formation. Consultez les détails ci-dessous.",
            },
          },
          sb,
        });
        break;
      }

      case "alerte_vente": {
        // Fetch current wallet balance
        const { data: wallet } = await sb.from("wallets").select("balance_xof").eq("user_id", payload.userId as string).maybeSingle();
        await notifyUser({
          userId: payload.userId as string,
          emailConfig: {
            templateId: 8,
            from: "contact@omniaglobalacademy.com",
            params: {
              FORMATION_TITRE: payload.formation_titre as string,
              MONTANT_XOF: payload.montant_xof as number,
              COMMISSION_XOF: payload.commission_xof as number,
              ACHETEUR_PAYS: payload.acheteur_pays as string || "",
              SOLDE_TOTAL_XOF: wallet?.balance_xof ?? 0,
            },
          },
          smsMessage: `Omnia Academy : Nouvelle vente ! "${payload.formation_titre}" vendu. +${payload.commission_xof} XOF crédités. Solde : ${wallet?.balance_xof ?? 0} XOF`,
          sb,
        });
        break;
      }

      case "certificat_genere": {
        await notifyUser({
          userId: payload.userId as string,
          emailConfig: {
            templateId: 9,
            from: "admission@omniaglobalacademy.com",
            params: {
              FORMATION_TITRE: payload.formation_titre as string,
              CERTIFICATE_ID: payload.certificate_id as string,
              VERIFY_URL: payload.verify_url as string,
              PDF_URL: payload.pdf_url as string,
              CPD_HOURS: payload.cpd_hours as number,
              IS_CPD: payload.is_cpd as boolean,
            },
          },
          smsMessage: `Omnia Academy : Felicitations ! Votre certificat "${payload.formation_titre}" est disponible. Telechargez-le : ${payload.pdf_url}`,
          sb,
        });
        break;
      }

      case "retrait_approuve": {
        await notifyUser({
          userId: payload.userId as string,
          emailConfig: {
            templateId: 8,
            from: "contact@omniaglobalacademy.com",
            params: {
              FORMATION_TITRE: "Demande de retrait",
              MONTANT_XOF: payload.montant_xof as number,
              COMMISSION_XOF: 0,
              ACHETEUR_PAYS: "",
              SOLDE_TOTAL_XOF: payload.solde_xof as number || 0,
              MESSAGE: `Votre retrait de ${payload.montant_xof} XOF a été approuvé. Traitement sous 24h ouvrées.`,
            },
          },
          smsMessage: `Omnia Academy : Votre retrait de ${payload.montant_xof} XOF a été approuvé. Traitement sous 24h ouvrées.`,
          sb,
        });
        break;
      }

      case "retrait_rejete": {
        await notifyUser({
          userId: payload.userId as string,
          smsMessage: `Omnia Academy : Votre demande de retrait de ${payload.montant_xof} XOF a été refusée. Raison : ${payload.raison}. Contactez le support.`,
          sb,
        });
        break;
      }

      case "facture_disponible": {
        await notifyUser({
          userId: payload.userId as string,
          emailConfig: {
            templateId: 8,
            from: "contact@omniaglobalacademy.com",
            params: {
              FORMATION_TITRE: payload.formation_titre as string,
              MONTANT_XOF: payload.montant_xof as number,
              COMMISSION_XOF: 0,
              ACHETEUR_PAYS: "",
              SOLDE_TOTAL_XOF: 0,
              FACTURE_NUM: payload.invoice_number as string,
              FACTURE_URL: payload.invoice_url as string,
            },
          },
          smsMessage: `Omnia Academy : Votre facture #${payload.invoice_number} pour "${payload.formation_titre}" est disponible : ${payload.invoice_url}`,
          sb,
        });
        break;
      }

      case "invitation_enseignant":
      case "invitation_moderateur": {
        const roleName = type === "invitation_enseignant" ? "Enseignant" : "Modérateur";
        await sendBrevoEmail({
          templateId: 1,
          to: { email: payload.email as string, name: payload.full_name as string },
          params: {
            PRENOM: (payload.full_name as string || "").split(" ")[0],
            ROLE_NAME: roleName,
            EMAIL: payload.email as string,
            TEMPORARY_PASSWORD: payload.temporary_password as string,
            LOGIN_URL: `${appUrl}/connexion`,
          },
          from: "support@omniaglobalacademy.com",
          userId: payload.userId as string,
          sb,
        });
        break;
      }

      case "tarif_ecole_propose": {
        await notifyUser({
          userId: payload.userId as string,
          emailConfig: {
            templateId: 5,
            from: "contact@omniaglobalacademy.com",
            params: {
              SCHOOL_NAME: payload.school_name as string,
              DIRECTOR_NAME: payload.director_name as string,
              FORMATION_TITRE: payload.formation_titre as string,
              SCHOOL_PERCENT: payload.school_percent as number,
              PLATFORM_PERCENT: payload.platform_percent as number,
              SCHOOL_AMOUNT: payload.school_amount as number,
              PLATFORM_AMOUNT: payload.platform_amount as number,
              ACTION_URL: payload.action_url as string || `${appUrl}/school/dashboard`,
            },
          },
          sb,
        });
        break;
      }

      case "anti_abandon": {
        const courseUrl = payload.last_lesson_id
          ? `${appUrl}/cours/${payload.course_id}/apprendre/${payload.last_lesson_id}`
          : `${appUrl}/cours/${payload.course_id}/apprendre`;

        await notifyUser({
          userId: payload.userId as string,
          emailConfig: {
            templateId: 4,
            from: "admission@omniaglobalacademy.com",
            params: {
              ROLE_NAME: "Apprenant",
              MESSAGE_SPECIFIQUE: `Votre formation "${payload.formation_titre}" vous attend ! Vous en êtes à ${payload.completion_percent ?? 0}%. Continuez sur votre lancée !`,
              DASHBOARD_URL: courseUrl,
            },
          },
          smsMessage: `Omnia Academy : Votre formation "${payload.formation_titre}" vous attend ! Reprenez dès maintenant.`,
          sb,
        });
        break;
      }

      default:
        return json({ error: "UNKNOWN_TYPE", type }, 400);
    }

    return json({ success: true, type });
  } catch (err) {
    return json({ error: "INTERNAL", message: (err as Error).message }, 500);
  }
});
